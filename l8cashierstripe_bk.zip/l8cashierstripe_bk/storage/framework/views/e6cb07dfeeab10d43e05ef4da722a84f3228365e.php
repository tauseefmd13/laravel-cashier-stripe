

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <?php echo e(__('All Subscription')); ?>

                    
                    <div class="col-xs-12 col-sm-12 col-md-12 text-right" style="margin-top:-25px;">
						<a class="btn btn-sm btn-primary pull-right" href="<?php echo e(route('subscriptions.create')); ?>"> Create Subscription</a>
					</div>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <table class="table table-bordered">
                        <tr>
				            <th>S.No.</th>
				            <th>Amount</th>
				            <th>Interval</th>
				            <th>End Date</th>
				            <th>Action</th>
				        </tr>
                        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td>$<?php echo e(number_format($subscription->plan->amount/100,2)); ?></td>
                            <td><?php echo e($subscription->plan->interval_count .' '. $subscription->plan->interval); ?></td>
                            <td><?php echo e(date('Y-m-d H:i:s',$subscription->current_period_end)); ?></td>
                            <td>
                                <a class="btn btn-sm btn-warning" href="<?php echo e(route('subscriptions.show',$subscription->id)); ?>">View</a>

                                <?php if(empty($subscription->canceled_at)): ?>
                                    <form action="<?php echo e(route('subscriptions.cancel',$subscription->id)); ?>" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to cancel ?');">Cancel</button>
                                    </form>
                                <?php else: ?>
                                    <form action="<?php echo e(route('subscriptions.resume',$subscription->id)); ?>" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Are you sure to resume ?');">Resume</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\l8cashierstripe\resources\views/subscriptions/index.blade.php ENDPATH**/ ?>